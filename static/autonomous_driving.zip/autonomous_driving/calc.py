from math import exp

class CalendarMonths:
    months = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"]
    def __init__(self,start = 0, year = 2025):
        self.cur = start
        self.year = str(year)
        self.month = self.months[self.cur]
        self.paid = 0

    def next(self):
        self.cur += 1
        if self.cur == 12:
            self.cur = 0
            self.year = int(self.year)
            self.year +=1
            self.year = str(self.year)
        
        self.month = self.months[self.cur]
        return self.month, self.year
            

class Debt:
    def __init__(self,p,r,name='DEBT',set_min=None):
        self.p = p
        self.r = r
        self.name = name
        self.set_min = set_min
    
    def pay(self,amount):
        self.p -= amount
        self.paid += amount
    
    def cal_minimum(self):
        if self.set_min:
            return self.set_min
        intrest = self.cal_intrest()
        if self.p > 200:
            return self.p*0.01+intrest
        else:
            return self.p
    
    def cal_intrest(self):
        return self.p*exp((self.r/100.)*(30.5/365.25))-self.p
    
    def add_intrest(self):
        self.p+= self.cal_intrest()
        
    def show(self):
        print(f'${self.p:.2f}')
    
    def cycle(self,pay=None):
        self.paid = 0
        if pay == None:
            self.add_intrest()
            self.pay(self.cal_minimum())
        else:
            self.add_intrest()
            self.pay(pay)

def fixlength(string,length):
    # print(len(string))
    if len(string)<length:
        
        remain = length - len(string)
        total = string + ' '*remain
    else:
        total = string+' '
    return total
class PaymentCenter:
    def __init__(self,*debts,avalible=None):
        self.data = []
        self.calendar = CalendarMonths()
        self.debts = list(debts)
        if not avalible:
            self.budget = self.cal_total_min_payment()
        else:
            self.budget = avalible
        
        
        self.tablebody = ''

        self.debts = self.order()
    

        
    def order(self):
        debts ={}
        ordered = []
        for debt in self.debts:
            debts[debt.p] = debt
        
        for i in range(len(self.debts)):
            debt = min(debts)
            ordered.append(debts[debt])
            debts.pop(debt)
        ordered.reverse()
        return ordered


    def cal_total_min_payment(self):
        total = 0
        for debt in self.debts:
            total+=debt.cal_minimum()
        print(total)
        return total
    
    def get_min_principle(self):
        min = (self.debts[0], self.debts[0].p)
        hitzero = []
        for debt in self.debts:
            if min[1] > debt.p and debt.p > 0:
                min = (debt, debt.p)
            if debt.p <=0:
                hitzero.append(debt)
        
        for debt in hitzero:
            idx = self.debts.index(debt)
            self.debts.pop(idx)
        
        #print(f'{min[0].name} has the smallest principle of {min[1]}')
        return min[0]
    
    def formatHead(self):
        width = 20
        data = fixlength(self.calendar.year,10)
        data += fixlength(self.calendar.month,10)
        for debt in self.debts:
            data+=fixlength(f"{debt.name}: ${debt.p:.2f} (${debt.paid:.2f})",width)+'\t'
        self.tablebody+=data+'\n'
    
    def formatBody(self):
        width = 20
        data = fixlength(self.calendar.year,width)
        data += fixlength(self.calendar.month,width)
        for debt in self.debts:
            data+=fixlength(f"{debt.p:.2f}",width)+'\t'
        self.tablebody+=data+'\n'
        

    def cycle(self):
        avalible = self.budget
        self.calendar.next()
        
        for debt in self.debts:
            need = debt.cal_minimum()
            debt.cycle()
            avalible -= need
            
        
        while avalible > 0:
            lowest = self.get_min_principle()
            if lowest.p >= avalible:
                lowest.pay(avalible)
                
                avalible = 0
               
            else:
                avalible -= lowest.p
                lowest.pay(lowest.p)
                

            avalible = 0
        self.formatHead()
        #self.formatBody()

        
        
    
    def show(self):
        #print(self.tablehead)
        print(self.tablebody)
    
    def evolve(self):
        while True:
            try:
                self.cycle()
            except:
                break
        self.show()
    
    def export(self,file='paymentplan.txt'):
        file_ = open(file,'w')
        file_.write(self.tablebody)
        file_.close()

        
            



Capital1 = Debt(3645.45,29.5865,'Capital 1')
Apple = Debt(3793.54,28.49,'Apple')
Chase = Debt(5391.96,27.99,'Chase')
Wellsfargo = Debt(8531.23,22.65,'Wells Fargo')
Kay = Debt(2060,32.75,'Kay')
Care = Debt(1192,0,'Care',set_min=160)
SalieMae = Debt(30000,10,'Salie')
Gov = Debt(18000,5,'Gov')
Car = Debt(15000,8,'Car',set_min=400)
Laptop = Debt(1300,29,'Laptop',set_min=49)


Hub = PaymentCenter(Capital1,Apple,Chase,Wellsfargo,Kay,Care,SalieMae,Gov,Car,Laptop,avalible=2500)
print(Hub.cal_total_min_payment())
Hub.evolve()
Hub.export()



