import serial
import time
port=serial.Serial('COM11',115200,timeout=2)

while True:
    print(port.read_all())
    time.sleep(3)