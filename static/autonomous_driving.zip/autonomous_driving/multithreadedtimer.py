import time
import threading

def start(interval=0.1):
    temp = Timer(interval)
    threading.Thread(target=temp.start, daemon=True).start()  # Daemon thread so it doesn't block the main program
    return temp

class Timer:
    def __init__(self, interval=0.1):
        self.interval = interval
        self.running = True
        self.last_printed = None  # To store the last printed time value

    def start(self):
        dt = 0
        time_ = time.time()
        print(f"{dt:.2f}")  # Initial message, use \r to stay on the same line
        while self.running:
            time.sleep(self.interval)
            dt = time.time() - time_
            
            # If the printed time value has changed, print it on the same line
            print(f"{dt:.2f}")  # Overwrites the previous print on the same line
       

    def stop(self):
        self.running = False
        print() 


        
    
