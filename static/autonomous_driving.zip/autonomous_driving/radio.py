import serial
import threading
from queue import Queue

class TransferType:
    SYSTEM_DATA = 0
    HIT_DATA = 1
    GPS_DATA = 2
    BATT_DATA1 = 3
    BATT_DATA2 = 4


class TransferPacket:
    def __init__(self):
        self.reserved = 0
        self.type = None
        self.paylen = 0
        self.serial = 0
        self.payload = []


class ClientSysData:
    def __init__(self):
        self.client_id = 0
        self.state = 0
        self.error_bits = 0
        self.path_name = ""


class ClientHitData:
    def __init__(self):
        self.hit_threshold = 0
        self.hit_time_limit = 0
        self.hd_sensitivity = 0
        self.hit_pause_time = 0
        self.hit_zone_data = 0
        self.zones_enable = False


class ClientGPSData:
    def __init__(self):
        self.utm_x = 0
        self.utm_y = 0
        self.num_sat1 = 0
        self.num_sat2 = 0
        self.gps_fix1 = 0
        self.gps_fix2 = 0
        self.cog = 0
        self.speed = 0
        self.mot_speed = 0
        self.flags = 0


class ClientBattData1:
    def __init__(self):
        self.bvolt = []
        self.bcap = []
        self.bcur = []


class ClientBattData2:
    def __init__(self):
        self.btemp1 = []
        self.btemp2 = []
        self.btemp3 = []
        self.otemp = []


class SimisUSB:
    BR1 = 115200
    def __init__(self, port="COM9", baudrate=9600):
        self.serial_port = serial.Serial(port, baudrate, timeout=1)
        self.msg_queue = Queue()
        self.packet = TransferPacket()
        self.system = ClientSysData()
        self.hits = ClientHitData()
        self.gps = ClientGPSData()
        self.batt1 = ClientBattData1()
        self.batt2 = ClientBattData2()
        self.running = False

    def process_message(self):
        while self.running:
            if not self.msg_queue.empty():
                msg = self.msg_queue.get()
                if (msg[0] & 0xF) == 0xD:
                    self.packet.reserved = msg[0] & 0xF
                    self.packet.type = msg[0] >> 4 & 0xF
                    self.packet.paylen = msg[1]
                    self.packet.serial = (msg[3] << 8) | msg[2]

                    if self.packet.type == TransferType.SYSTEM_DATA:
                        self.system.client_id = msg[4]
                        self.system.state = msg[5]
                        self.system.error_bits = msg[6]
                        print('System Data')
                        # Additional processing here...

                    elif self.packet.type == TransferType.HIT_DATA:
                        self.hits.hit_threshold = msg[4]
                        self.hits.hit_time_limit = msg[5]
                        self.hits.hd_sensitivity = msg[6]
                        self.hits.hit_pause_time = msg[7]
                        self.hits.hit_zone_data = msg[8]
                        self.hits.zones_enable = bool(msg[9])

                    elif self.packet.type == TransferType.GPS_DATA:
                        print('GPS')
                        self.gps.utm_x = (msg[4] << 24 | msg[5] << 16 | msg[6] << 8 | msg[7]) // 10
                        self.gps.utm_y = (msg[8] << 24 | msg[9] << 16 | msg[10] << 8 | msg[11]) // 10
                        self.gps.num_sat1 = msg[12]
                        self.gps.num_sat2 = msg[13]
                        self.gps.gps_fix1 = msg[14]
                        self.gps.gps_fix2 = msg[15]
                        self.gps.cog = msg[16]
                        self.gps.speed = msg[17]
                        self.gps.mot_speed = msg[18]
                        self.gps.flags = msg[19]

                    elif self.packet.type == TransferType.BATT_DATA1:
                        self.batt1.bcap = msg[5:5+len(self.batt1.bcap)]

                    elif self.packet.type == TransferType.BATT_DATA2:
                        pass  # Process battery data part 2

    def read_serial(self):
        buf = []
        idx = 0
        r_state = 0
        while self.running:
            print('Reading')
            byte = self.serial_port.read()
            print('Read:',byte,'#END MESSAGE')

            if not byte:
                continue

            byte = ord(byte)  # Convert byte to integer

            if r_state == 0 and (byte & 0xF) == 0xD:
                buf.append(byte)
                r_state = 1
                idx += 1

            elif r_state == 1:
                buf.append(byte)
                r_state = 2
                idx += 1

            elif r_state == 2:
                buf.append(byte)
                idx += 1
                if idx > buf[1]:
                    r_state = 3

            elif r_state == 3:
                self.msg_queue.put(buf.copy())
                buf.clear()
                idx = 0
                r_state = 0

    def start(self):
        self.running = True
        threading.Thread(target=self.read_serial, daemon=True).start()
        threading.Thread(target=self.process_message, daemon=True).start()

    def stop(self):
        self.running = False
        self.serial_port.close()


if __name__ == "__main__":
    simis = SimisUSB(port="COM9")
    try:
        simis.start()
        while True:
            pass
    except KeyboardInterrupt:
        simis.stop()
