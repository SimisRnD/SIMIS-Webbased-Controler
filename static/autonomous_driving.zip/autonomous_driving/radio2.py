import serial
import threading
import time
import random

class SerialPortManager:
    def __init__(self, port, baud_rate=9600):
        self.port = port
        self.baud_rate = baud_rate
        self.serial_port = None
        self.read_thread = None
        self.running = False

    def open_port(self):
        try:
            self.serial_port = serial.Serial(self.port, self.baud_rate, timeout=1)
            self.running = True
            self.read_thread = threading.Thread(target=self.read_from_port, daemon=True)
            self.read_thread.start()
            print(f"Opened port {self.port} at {self.baud_rate} baud rate.")
        except serial.SerialException as e:
            print(f"Error opening port {self.port}: {e}")

    def close_port(self):
        self.running = False
        if self.read_thread and self.read_thread.is_alive():
            self.read_thread.join()
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
            print(f"Closed port {self.port}.")

    def read_from_port(self):
        while self.running:
            try:
                if self.serial_port.in_waiting > 0:
                    data = self.serial_port.readline().decode('utf-8').strip()
                    self.handle_received_data(data)
            except serial.SerialException as e:
                print(f"Error reading from port: {e}")
                self.running = False

    def handle_received_data(self, data):
        """Handles data received from the serial port."""
        print(f"Received: {data}")

    def write_to_port(self, message):
        try:
            if self.serial_port and self.serial_port.is_open:
                self.serial_port.write(message.encode('utf-8'))
                print(f"Sent: {message}")
        except serial.SerialException as e:
            print(f"Error writing to port: {e}")

# Example usage
def simulate_serial_data(manager, interval=2):
    """Simulates incoming serial data."""
    while manager.running:
        fake_data = f"RandomValue: {random.randint(1, 100)}"
        manager.handle_received_data(fake_data)  # Call directly instead of sending to port
        time.sleep(interval)

def main():
    port = "COM11"  # Change this to your port name
    baud_rate = 9600

    manager = SerialPortManager(port, baud_rate)
    try:
        manager.open_port()

        SerialPortManager.write_to_port()

        # Keep the program running
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Exiting program.")
    finally:
        manager.close_port()

if __name__ == "__main__":
    main()
