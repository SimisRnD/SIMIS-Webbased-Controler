import serial
import struct
import time

# USB communication settings (adjust these as needed)
USB_PORT = "COM9"  # Replace with the appropriate port
BAUD_RATE = 115200        # Match the baud rate configured in the C program
TIMEOUT = 10               # Timeout for reading, in seconds

# Define packet types
SYSTEM_DATA = 0x01
GPS_DATA = 0x02
HIT_DATA = 0x03
BATT_DATA1 = 0x04
BATT_DATA2 = 0x05

# TransferPacket structure
PACKET_HEADER = 0xD

class USBCommunicator:
    def __init__(self, port, baudrate):
        self.serial = serial.Serial(port, baudrate, timeout=TIMEOUT)

    def send_request(self, packet_type, client_id):
        """Send a request packet to the USB device."""
        # Create the TransferPacket
        header = PACKET_HEADER
        payload = struct.pack("<B", client_id)  # Simple payload with client_id
        paylen = len(payload)

        # Pack the TransferPacket: [header][type][payload length][payload]
        packet = struct.pack("<BBBB", header, packet_type,paylen,client_id) #+ payload
        self.serial.write(packet)
        print(f"Sent packet: {packet}")

    def read_response(self):
        """Read and parse the response from the USB device."""
        try:
            response = self.serial.read(256)  # Adjust max length as needed
            if response:
                print(f"Received raw data: {response.hex()}")
                # Parse the response (customize this based on your protocol)
                header, ptype = struct.unpack("<BB", response[:2])
                payload = response[2:]
                print(f"Header: {header}, Type: {ptype}, Payload: {payload}")
                return payload
        except Exception as e:
            print(f"Error reading response: {e}")
        return None

    def close(self):
        """Close the serial connection."""
        self.serial.close()

def main():
    # Initialize USB communicator
    communicator = USBCommunicator(USB_PORT, BAUD_RATE)

    try:
        # Request data from the device
        for client_id in range(5):  # Example: Iterate over client IDs
            for packet_type in (SYSTEM_DATA, GPS_DATA, HIT_DATA, BATT_DATA1, BATT_DATA2):
                communicator.send_request(packet_type, client_id)
                time.sleep(0.5)  # Wait before reading response
                response = communicator.read_response()
                if response:
                    print(f"Client {client_id}, Packet Type {packet_type}: \n\nResponse:\n{response}")
                time.sleep(1)  # Wait before the next request

    finally:
        # Ensure the connection is closed
        communicator.close()

if __name__ == "__main__":
    main()
