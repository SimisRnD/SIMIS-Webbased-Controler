from enum import Enum
import serial
import serial.tools.list_ports
import ctypes

# Enum for transfer types
class _TransferType:
    REQUEST_DATA = 0
    SYSTEM_DATA = 1
    HIT_DATA = 2
    GPS_DATA = 3
    BATT_DATA1 = 4
    BATT_DATA2 = 5
    PATH_DATA = 6

# Enum for system state
class _TSystemState(Enum):
    CCPU_STATE_INIT = 1
    CCPU_STATE_RC = 2
    CCPU_STATE_SCEN = 3
    CCPU_STATE_RECORD = 4
    CCPU_STATE_HITPAUSE = 5
    CCPU_STATE_LOWBATTERY = 6
    CCPU_STATE_FAULT = 7
    CCPU_STATE_DO_NOTHING = 8
    CCPU_STATE_EMPTYBATTERY = 9
    CCPU_STATE_POST_BOOT = 10
    CCPU_STATE_PRE_INIT = 11
    CCPU_STATE_PRE_OFF = 12
    CCPU_STATE_FORM_L = 13
    CCPU_STATE_FORM_F = 14
    CCPU_STATE_ESTOP = 15
    CCPU_STATE_INVALID = 255

# Error codes
class _TErrorCode(Enum):
    ERR_NONE = 0x0000
    ERR_MOT1 = 0x0001
    ERR_MOT2 = 0x0002
    ERR_MOT3 = 0x0004
    ERR_MOT4 = 0x0008
    ERR_RADIO_HW = 0x0010
    ERR_RADIO_PROTO = 0x0020
    ERR_FAN_TOP = 0x0040
    ERR_FAN_BOT = 0x0080
    ERR_NO_BATTERY = 0x0100
    ERR_NO_HITDET = 0x0200
    ERR_NO_RISER = 0x0400
    ERR_NO_GPS1 = 0x0800
    ERR_NO_GPS2 = 0x1000
    ERR_MOT_NOTRDY = 0x2000
    ERR_FAN_PDB = 0x4000

# Packet structure
class _TTransferPacket:
    def __init__(self):
        self.reserved = 0
        self.type = _TransferType()
        self.paylen = 0
        self.serial = 0
        self.payload = []

# Data structures for requests and data
class TRequestData(ctypes.Structure):
    _fields_ = [
        ("request_type", ctypes.c_uint8),  # 1-byte integer
        ("cycle", ctypes.c_uint8)         # 1-byte integer
    ]

class Data:
    def __init__(self):
        pass

    def GetAll(self):
        data = {}
        for att, val in vars(self).items():
            data[att] = val
        return data

    def PrintAll(self):
        data = self.GetAll()
        for att in data:
            print(f'{att} = {data[att]}')

# Functions for handling transfer packets
def GetTransferPacket(buf):
    pack = _TTransferPacket()
    if (buf[0] >> 4) & 0xF == 0xD:
        pack.reserved = 0xD
        pack.type = (buf[0] >> 0) & 0xF
        pack.paylen = buf[1]
        pack.serial = (buf[3] << 8) | (buf[2] & 0xFF)
        pack.payload = buf[4:4 + pack.paylen]
    return pack

# Request Functions
def SendRequest(serial_port, request_type, cycle=1):
    """
    Sends a request to the connected device.

    Args:
        serial_port: The open serial.Serial object.
        request_type: The type of data requested (_TransferType).
        cycle: Optional cycle value for certain requests (default is 0).
    """
    if not isinstance(serial_port, serial.Serial) or not serial_port.is_open:
        raise ValueError("Serial port is not open or invalid.")
    
    # Create the request data
    data = TRequestData(request_type, cycle)
    
    # Pack into a byte array
    payload = bytearray([request_type,cycle])
    #ctypes.memmove(ctypes.addressof(data), payload, ctypes.sizeof(data))
    
    # Add metadata for transfer
    reserved_type = (0xD << 4) | request_type
    paylen = len(payload)
    header = [reserved_type, paylen, 0x00, 0x00]  # Serial number placeholder
    packet = header + list(payload)
    packet = bytearray(packet)
    
    # Send over serial
    print(f'Sending {packet}')
    serial_port.write(bytearray(packet))

    data = serial_port.read()
    state = 0
    if data:
        serial_port.reset_input_buffer()
        if state == 0 and ((data >> 0) & 0xF) == 0xD:
            print('True')
        else:
            print('False')
    return data

def RequestSystemData(serial_port):
    """
    Sends a request to retrieve system data.
    """
    return SendRequest(serial_port, _TransferType.SYSTEM_DATA,cycle=0)

def RequestHitData(serial_port):
    """
    Sends a request to retrieve hit data.
    """
    return SendRequest(serial_port, _TransferType.HIT_DATA)

def RequestGPSData(serial_port):
    """
    Sends a request to retrieve GPS data.
    """
    return SendRequest(serial_port, _TransferType.GPS_DATA)

def RequestBatteryData1(serial_port):
    """
    Sends a request to retrieve battery data (set 1).
    """
    return SendRequest(serial_port, _TransferType.BATT_DATA1)

def RequestBatteryData2(serial_port):
    """
    Sends a request to retrieve battery data (set 2).
    """
    return SendRequest(serial_port, _TransferType.BATT_DATA2)

# Example usage of the request functions
def Main():
    # Get available serial ports
    ports = 'COM9'
    if not ports:
        print("No serial ports found.")
        return
    
    # Open the first available port (as an example)
    with serial.Serial(ports, 115200, timeout=5) as serial_port:
        serial_port.write_timeout = 5
        print(f"Connected to {ports}.")


        
        # Send requests
        print('System Data:',RequestSystemData(serial_port))
        print('GPS Data:   ',RequestGPSData(serial_port))
        print('Battery1 Data:',RequestBatteryData1(serial_port))
        print('Battery2 Data:',RequestBatteryData2(serial_port))

Main()
