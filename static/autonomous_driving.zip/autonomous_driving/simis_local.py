from flask import Flask, render_template, jsonify, request, send_file, Response, send_from_directory
from PIL import Image, ImageDraw
from genfeed import generate_frames

WAYPOINTS = {}
for i in range(1,9):
    WAYPOINTS[i] = []


app = Flask(__name__)

# Distinct Pages
@app.route('/')
def index():
    return render_template('dashboard.html')


# Distinct Pages
@app.route('/controler')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
def controler():
    return render_template('controler.html')


# Distinct Pages
@app.route('/connect')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
def connect():
    return render_template('connect.html')


# Route to download the ZIP file
@app.route('/_download')
def _download():
    return send_from_directory(
        directory='static',  # Directory where the file is stored
        path='autonomous_driving.zip',   # File name
        as_attachment=True   # Forces download
    )


# Route for the homepage
@app.route('/download')
def download():
    return render_template('download.html')

# Distinct Pages
@app.route('/statistics')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
def statistics():
    return render_template('statistics.html')

# Joystick backend
@app.route('/_joystick', methods=['POST'])
def joystick():
    data = request.get_json()
    power = data.get('POWER', '0')
    angle = data.get('ANGLE', '0')
    print('Power ', float(power),'Angle ',float(angle))
    return {'Bet':'Got it'}, 200

# Joystick backend
@app.route('/_buttons', methods=['POST'])
def buttons():
    data = request.get_json()
    button = data.get('BUTTON', '0')
    print('Button: ',button)
    return {'Bet':f'Got it, button {button}'}, 200

# Joystick backend
@app.route('/_gps/add_way_point', methods=['POST'])
def add_waypoints():
    global WAYPOINTS
    data = request.get_json()
    target = data.get('TAR', None)
    lat = data.get('LAT', None)
    lon = data.get('LON',None)
    
    if target and lat and lon:
        WAYPOINTS[target].append([lat,lon])
    print('Added: ',(target,lat,lon))

    
    return {'Bet':f'{target}:({lat},{lon})'}, 200

@app.route('/video_feed')
def video_feed():
    # Return a response with the frames generated by the webcam
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == '__main__':
    # Run Flask app with access from other devices on the network
    app.run(host='0.0.0.0', port=5000, debug=True)
