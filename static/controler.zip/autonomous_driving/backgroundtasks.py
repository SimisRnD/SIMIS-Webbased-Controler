import time
import threading
import uuid

def start(interval=0.1):
    temp = Timer(interval)
    threading.Thread(target=temp.start, daemon=True).start()  # Daemon thread so it doesn't block the main program
    return temp

class Timer:
    def __init__(self, interval=0.1):
        self.interval = interval
        self.running = True
        self.last_printed = None  # To store the last printed time value

    def start(self):
        dt = 0
        time_ = time.time()
        print(f"{dt:.2f}")  # Initial message, use \r to stay on the same line
        while self.running:
            time.sleep(self.interval)
            dt = time.time() - time_
            
            # If the printed time value has changed, print it on the same line
            print(f"{dt:.2f}")  # Overwrites the previous print on the same line
       

    def stop(self):
        self.running = False
        print() 

class Scheduler:
    def __init__(self):
        self.signals = {}
        self.threads = {}
    
    def loop(self,function,signal,args=[],time_int=None):
        while self.signals[signal]:
            function(*args)
            if time_int:
                time.sleep(time_int)
        del(self.signals[signal])
        del(self.threads[signal])
    
    def looper(self,function,args=[],time_int=0.5,):
        signal = uuid.uuid4()
        self.signals[signal] = True
        thread = threading.Thread(target=self.loop,kwargs={'function':function,
                                                         'signal':signal,
                                                         'time_int':time_int,
                                                         'args':args})
        self.threads[signal] = thread

        thread.start()

        stopper = lambda x=signal: self.stop(signal=x)
        return signal, stopper

    
    def stop(self,signal):
        
        self.signals[signal] = False
        
        



if __name__ == '__main__':
    def f(name):
        print(name,time.time())

    example = Scheduler()
    task, stopper = example.looper(f,time_int=0.1,args=('Trent:',))
    time.sleep(2)
    stopper()


        
    
