from flask import Flask, render_template
import random

app = Flask(__name__)

# Simulated function to get diagnostic data
def get_robot_diagnostics():
    return {
        "System": {
            "Serial": random.randint(1000, 9999),
            "Client ID": random.randint(1, 10),
            "State": random.choice(["Idle", "Active", "Error"]),
            "Errors": ["ERR_MOT1", "ERR_NO_BATTERY"] if random.random() > 0.5 else [],
            "Path Name": "Mission Alpha",
        },
        "Battery 1": {
            "Voltage": f"{random.uniform(11.5, 13.0):.2f}V",
            "Capacity": random.randint(50, 100),
            "Current": f"{random.uniform(0.5, 2.0):.2f}A",
        },
        "Battery 2": {
            "Temperature Sensors": [random.randint(20, 50) for _ in range(3)],
        },
        "GPS": {
            "Latitude": f"{random.uniform(-90, 90):.6f}",
            "Longitude": f"{random.uniform(-180, 180):.6f}",
            "Satellites": random.randint(4, 12),
            "Speed": f"{random.uniform(0, 10):.2f} m/s",
        },
    }

@app.route("/")
def index():
    diagnostics = get_robot_diagnostics()
    return render_template("dark_diag.html", diagnostics=diagnostics)

if __name__ == "__main__":
    app.run(debug=True)
