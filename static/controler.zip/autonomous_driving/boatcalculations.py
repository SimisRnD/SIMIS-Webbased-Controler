from math import cos, sin, pi, degrees, radians

print('x',-275.8*0.563+231.4*0.325)