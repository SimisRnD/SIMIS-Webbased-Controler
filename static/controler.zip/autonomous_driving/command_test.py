import struct
import serial
import serial.tools.list_ports

def getPortDetails():
    ports = serial.tools.list_ports.comports()
    port_details = [
        (port.device, port.description, port.hwid) for port in ports
    ]
    print(port_details)
    return port_details

def usbPorts():
    ports = getPortDetails()
    usb_ports = [port for port, _, hwid in ports if 'usb' in hwid.lower()]
    return usb_ports

def openPort(port=None, baud=115200, timeout=0.5, writeout=0.5):
    if port is None:
        available_ports = usbPorts()
        if not available_ports:
            raise ValueError("No USB ports found!")
        port = available_ports[0]
    
    return serial.Serial(port=port, baudrate=baud, timeout=timeout, write_timeout=writeout)

class Joystick:
    def __init__(self):
        self.xa = 0
        self.ya = 0
        self.za = 0
        self.btn = 0

class RCPayload:
    def __init__(self):
        self.active_client = 0
        self.resp_client = 0
        self.cycle = 0
        self.ptype = 0  # CONTROLLER_INPUT equivalent
        self.state = 0
        self.hit_threshold = 0
        self.hit_time_limit = 0
        self.joyX = 0
        self.joyY = 0
        self.joyZ = 0
        self.btns = 0

class TRadioPacket:
    def __init__(self):
        self.cmd = 0x81
        self.paylen = 0
        self.reserved = 0
        self.retries = 1
        self.dest1 = 0xFF
        self.dest2 = 0xFF
        self.dest3 = 0xFF
        self.payload = bytearray(80)  # Ensure payload is a bytearray

class ClientData:
    def __init__(self):
        self.state = 0
        self.hitThreshold = 0
        self.hitTimeLimit = 0
        self.msgSent = 0
        self.msgRecv = 0
        self.commPerf = [0] * 10  # Assuming COMM_PERF_SIZE is 10
        self.commPerfIdx = 0
        self.gotPacketFlag = False

# Simulated client list
clientList = [ClientData() for _ in range(10)]

# Simulated global variables
g_menuMode = False
noMove = 0

def IsClicked(button):
    """Simulated function to check button press."""
    return 0  # Modify this to check actual button states

def GetJoystickInfo(joy):
    """Simulated function to get joystick data."""
    joy.xa = -5  # Replace with actual joystick readings
    joy.ya = 0
    joy.za = 0
    joy.btn = 1  # Simulating a button press

def BuildAndSendRcPacket(destCli, respCli, cycle):
    global noMove

    p = TRadioPacket()
    rc = RCPayload()
    joy = Joystick()

    # Set packet header
    rc.active_client = destCli
    rc.resp_client = respCli
    rc.cycle = cycle
    rc.ptype = 0x00  # CONTROLLER_INPUT
    rc.state = clientList[destCli - 1].state
    rc.hit_threshold = clientList[destCli - 1].hitThreshold
    rc.hit_time_limit = clientList[destCli - 1].hitTimeLimit

    # Get joystick info
    GetJoystickInfo(joy)

    if joy.btn:
        noMove = 15
    else:
        noMove = max(0, noMove - 1)

    if g_menuMode or noMove:
        rc.joyX = rc.joyY = rc.joyZ = 0
    else:
        rc.joyX = joy.xa
        rc.joyY = joy.ya
        rc.joyZ = joy.za

    rc.btns = joy.btn
    rc.btns |= (IsClicked("RISER_UP") << 1)
    rc.btns |= (IsClicked("RISER_DOWN") << 2)
    rc.btns |= (IsClicked("SHFT_BTN") << 3)

    # Pack RCPayload into bytes
    rc_payload_packed = struct.pack(
        "<BBBBHHBBB",
        rc.active_client, rc.resp_client, rc.cycle, rc.ptype,
        rc.hit_threshold, rc.hit_time_limit,
        rc.joyX, rc.joyY, rc.joyZ
    )

    # Assign payload and update payload length
    p.paylen = len(rc_payload_packed)
    p.payload[:p.paylen] = rc_payload_packed  # Copy data to bytearray

    # Build TRadioPacket and send via serial
    radio_packet_packed = struct.pack(
        "<BBBBBBB", p.cmd, p.paylen, p.reserved, p.retries, p.dest1, p.dest2, p.dest3
    ) + p.payload[:p.paylen]  # Only send used payload bytes

    # Print debug information
    print(f"Sending RC packet to {destCli}, respCli={respCli}, len={7 + p.paylen}")
    print(f"  Rc = {rc.joyX}, {rc.joyY}, {rc.joyZ}, 0x{rc.btns:X}")
    print(f"  Packet Data: {radio_packet_packed}")

    # Simulated sending via serial
    try:
        ser = openPort()
        ser.write(radio_packet_packed)
        print(ser.readline())
        ser.close()
    except Exception as e:
        print(f"Serial error: {e}")

    # Update client radio performance diagnostics
    pC = clientList[respCli - 1]  # shorthand
    pC.msgSent += 1
    pC.commPerf[pC.commPerfIdx] = 1 if pC.gotPacketFlag else 0
    pC.commPerfIdx = (pC.commPerfIdx + 1) % len(pC.commPerf)
    pC.gotPacketFlag = False

    # Prevent LCD overflow by resetting counters
    if pC.msgSent > 9999:
        pC.msgSent = 0
        pC.msgRecv = 0

# Example call
for i in range(10):
    BuildAndSendRcPacket(1, 1, 100)
