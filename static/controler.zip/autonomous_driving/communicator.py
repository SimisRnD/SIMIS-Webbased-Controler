import serial
import time
import threading


PORT = 'COM11'
BUADRATE = 115200
TIMEOUT = 2
SWITCH = True


def keyboard_quit():
    global SWITCH
    input('Press Enter to quit.')
    SWITCH = False


com_port = serial.Serial(port=PORT,
                         baudrate=BUADRATE,
                         timeout=TIMEOUT)
action = threading.Thread(target=keyboard_quit)
action.start()
while SWITCH:
    print(com_port.read())
    time.sleep(0.5)