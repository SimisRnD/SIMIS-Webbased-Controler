from math import degrees, sin, cos, pi, radians, atan

class Data:
    def __init__(self):
        pass
    def GetAll(self):
        data = {}
        for att, val in vars(self).items():
            data[att] = val
        return data
    def PrintAll(self):
        data = self.GetAll()
        for att in data:
            print(f'{att} = {data[att]}')


class Vector(Data):
    def __init__(self,**kwargs):
        self.x = kwargs.get('x',None)
        self.y = kwargs.get('y',None)
        self.mag = kwargs.get('mag',None)
        self.ang =kwargs.get('ang',None)
        self.type = kwargs.get('type','deg')

        if not self.x and (self.mag and self.ang):
            if self.type == 'deg':
                self.x = self.mag*cos(radians(self.ang))
            else:
                self.x = self.mag*cos(self.ang)
        
        if not self.y and (self.mag and self.ang):
            if type == 'deg':
                self.y = self.mag*sin(radians(self.ang))
            else:
                self.y = self.mag*sin(self.ang)
        
        if self.ang == None:
            self.type = 'rad'
        if self.ang == None and (self.x and self.y):
            self.ang= atan(self.y/self.x)
        elif self.ang == None and self.x:
            self.ang = 0 if self.x > 0 else self.pi
        elif self.ang == None and self.y:
            self.ang = pi/2.0 if self.y > 0 else pi*3/2
            print(f'angel:{self.ang/pi}pi')
        
        if not self.mag:
            if self.x != None:
                if self.type == 'deg':
                    self.mag = self.x/cos(radians(self.ang))
                else:
                    self.mag = self.x/cos(self.ang)


            elif self.y !=None :
                if self.type == 'deg':
                    self.mag = self.y/sin(radians(self.ang))
                else:
                    self.mag = self.y/sin(self.ang)
            
            self.x = round(self.x,6) if self.x else self.x
            self.y = round(self.y,6) if self.y else self.y
            self.mag = round(self.mag,6) if self.mag else self.mag
            self.ang = round(self.ang,6) if self.ang else self.ang


        
    
a = Vector(y=-9.8)

    

