from enum import Enum
import serial
import serial.tools.list_ports
import ctypes
import time
from backgroundtasks import Scheduler
class _TransferType():
    REQUEST_DATA = 0
    SYSTEM_DATA = 1
    HIT_DATA = 2
    GPS_DATA = 3
    BATT_DATA1 = 4
    BATT_DATA2 = 5
    PATH_DATA = 6

class _TSystemState(Enum):
    CCPU_STATE_INIT         = 1
    CCPU_STATE_RC           = 2
    CCPU_STATE_SCEN         = 3
    CCPU_STATE_RECORD       = 4
    CCPU_STATE_HITPAUSE     = 5
    CCPU_STATE_LOWBATTERY   = 6
    CCPU_STATE_FAULT        = 7
    CCPU_STATE_DO_NOTHING   = 8
    CCPU_STATE_EMPTYBATTERY = 9
    CCPU_STATE_POST_BOOT    = 10
    CCPU_STATE_PRE_INIT     = 11
    CCPU_STATE_PRE_OFF      = 12
    CCPU_STATE_FORM_L       = 13
    CCPU_STATE_FORM_F       = 14
    CCPU_STATE_ESTOP        = 15
    CCPU_STATE_INVALID      = 255


class _TErrorCode (Enum):
    ERR_NONE        = 0x0000
    ERR_MOT1        = 0x0001
    ERR_MOT2        = 0x0002
    ERR_MOT3        = 0x0004
    ERR_MOT4        = 0x0008
    ERR_RADIO_HW    = 0x0010
    ERR_RADIO_PROTO = 0x0020
    ERR_FAN_TOP    = 0x0040
    ERR_FAN_BOT    = 0x0080
    ERR_NO_BATTERY = 0x0100
    ERR_NO_HITDET  = 0x0200
    ERR_NO_RISER   = 0x0400
    ERR_NO_GPS1    = 0x0800
    ERR_NO_GPS2    = 0x1000
    ERR_MOT_NOTRDY = 0x2000 
    ERR_FAN_PDB    = 0x4000
    

class _TTransferPacket:
    def __init__(self):
        self.reserved = 0
        self.type = _TransferType()
        self.paylen = 0
        self.serial = 0
        self.payload = []

class  _TTransferPacket_Serial:
    def __init__(self):
        self.reserved_and_type = 0
        self.paylen = 0
        self.serial = 0
        self.payload = []

class TRequestData(ctypes.Structure):
    _fields_ = [
        ("request_type", ctypes.c_uint8),  # Assuming 1-byte integer
        ("cycle", ctypes.c_uint8)         # Assuming 1-byte integer
    ]


class Data:
    def __init__(self):
        pass
    def GetAll(self):
        data = {}
        for att, val in vars(self).items():
            data[att] = val
        return data
    def PrintAll(self):
        data = self.GetAll()
        for att in data:
            print(f'{att} = {data[att]}')
            
class TClientSysData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'System Data'
        self.serial = 0
        self.clientId = 0
        self.state = 0
        self.errorbits = 0
        self.pathName_raw = 0
        self.pathName = 0

class TClientHitData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Hit Data'
        self.hitThreshold = 0
        self.hitTimeLimit = 0
        self.HdSensitivity = 0
        self.hitPauseTime = 0
        self.hit_zone_data = 0
        self.zonesEnable = 0
  

class TClientGPSData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'GPS Data'
        self.utmX = 0
        self.utmY = 0
        self.utmZone = 0
        self.numSat = 0
        self.gpsFix = 0
        self.COG = 0
        self.speed = 0


class TClientBattData1(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Battery 1 Data'
        self.bvolt = 0
        self.bcap = 0
        self.bcur = 0


class TClientBattData2(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Battery 2 Data'
        self.btemp1 = 0
        self.btemp2 = 0
        self.btemp3 = 0
        self.btemp4 = 0

class TClientPathWithSpace:
    def __init__(self):
        self.data_name = 'Path Data'
        self.name_raw = 0
        self.name = 0
        self.pathdate = 0
        self.pathtime = 0
        self.lat0 = 0
        self.lon0 = 0
        self.x0 = 0
        self.y0 = 0
        self.npts = 0
        self.curpt = 0
        self.x = 0
        self.y = 0
        self.flag = 0

def GetPortNames():
    ports = serial.tools.list_ports.comports()
    port_names = [port.device for port in ports]
    return port_names

def GetTransferPacket(buf):
    pack = _TTransferPacket()
    if((buf[0] >> 0)& 0xF == 0xD):
        pack.reserved = 0xD
        pack.type = _TransferType.REQUEST_DATA
        pack.paylen = buf[1]
        pack.serial = (buf[3] << 8) | (buf[2] & 0xFF)
        for i in range(0,pack.paylen):
            pack.payload.append(buf[4+i])
    return pack




def GetRequestData(pack):
    request = TRequestData()
    print('Data Request Packets',pack.payload)
    if (pack.type == _TransferType.REQUEST_DATA):
        pass

    else:

        request.request_type = pack.payload[0]
        request.cycle = pack.payload[1]
    
    return request

def GetClientSysData(pack):
    sysData = TClientSysData()
    
    if (pack.type == _TransferType.SYSTEM_DATA):
        pass

    else:
        sysData.serial = pack.serial
        sysData.clientId = pack.payload[0]
        sysData.state = pack.payload[1]
        sysData.errorbits = (pack.payload[3] << 8) | (pack.payload[2]&0xFF)
        sysData.pathName_raw = []
        sysData.pathName = ''
        for i in range(4, pack.paylen):
            sysData.pathName_raw.append(pack.payload[i])
            sysData.pathName+=str(pack.payload[i])
    sysData.PrintAll()
    return sysData

def GetHitData(pack):
    hitData = TClientHitData()
    
    if (pack.type == _TransferType.HIT_DATA):
        pass
    else:
        hitData.hitThreshold = pack.payload[0]
        hitData.hitTimeLimit = pack.payload[1]
        hitData.HdSensitivity = pack.payload[2]
        hitData.hitPauseTime = pack.payload[3]
        hitData.hit_zone_data = pack.payload[4]
        hitData.zonesEnable = bool(pack.payload[5])
    hitData.PrintAll()
    return hitData

def GetGPSData(pack):
    gpsData = TClientGPSData()
    print('GPS:',pack.type)
    if (pack.type == _TransferType.GPS_DATA):
        pass
    else:
        raw_utmX = ((pack.payload[3] << 24) | (pack.payload[2] << 16) | (pack.payload[1] << 8) | (pack.payload[0] & 0xFF))
        raw_utmY = ((pack.payload[7] << 24) | (pack.payload[6] << 16) | (pack.payload[5] << 8) | (pack.payload[4] & 0xFF))
        gpsData.utmX = raw_utmX / 10.
        gpsData.utmY = raw_utmY / 10.
        gpsData.utmZone =  [0,0,0,0]
        gpsData.utmZone[0] = pack.payload[8]
        gpsData.utmZone[1] = pack.payload[9]
        gpsData.utmZone[2] = pack.payload[10]
        gpsData.utmZone[3] = pack.payload[11]
        gpsData.numSat = pack.payload[12]
        gpsData.gpsFix =  pack.payload[13]
        gpsData.COG = pack.payload[14]
        gpsData.speed = pack.payload[15]
    gpsData.PrintAll()
    return gpsData

def GetBatt1Data(pack):
    print('Get Battdata',pack.type)
    batt1 = TClientBattData1()
    if (pack.type == _TransferType.BATT_DATA1):
        pass
    else:
        batt1.bvolt = [0,0]
        batt1.bvolt[0] = ((pack.payload[1] << 8) | (pack.payload[0] & 0xFF))
        batt1.bvolt[1] = ((pack.payload[3] << 8) | (pack.payload[2] & 0xFF))
        batt1.bcap = [0,0,0]
        batt1.bcap[0] = pack.payload[4]
        batt1.bcap[1] = pack.payload[5]
        batt1.bcap[2] = pack.payload[6]
        batt1.bcur = [0,0,0]
        batt1.bcur[0] = ((pack.payload[8] << 8) | (pack.payload[7] & 0xFF))
        batt1.bcur[1] = ((pack.payload[10] << 8) | (pack.payload[9] & 0xFF))
        batt1.bcur[2] = ((pack.payload[12] << 8) | (pack.payload[11] & 0xFF))
    batt1.PrintAll()
    return batt1


def GetBatt2Data(pack):
    batt2 = TClientBattData2()
    if (pack.type == _TransferType.BATT_DATA2):
        batt2.btemp1 = [0,0,0]
        batt2.btemp1[0] = pack.payload[0]
        batt2.btemp1[1] = pack.payload[1]
        batt2.btemp1[2] = pack.payload[2]
        batt2.btemp2 = [0,0,0]
        batt2.btemp2[0] = pack.payload[3]
        batt2.btemp2[1] = pack.payload[4]
        batt2.btemp2[2] = pack.payload[5]
        batt2.btemp3 = [0,0,0]
        batt2.btemp3[0] = pack.payload[6]
        batt2.btemp3[1] = pack.payload[7]
        batt2.btemp3[2] = pack.payload[8]
        batt2.otemp = [0,0,0,0,0]
        batt2.otemp[0] = pack.payload[9]
        batt2.otemp[1] = pack.payload[10]
        batt2.otemp[2] = pack.payload[11]
        batt2.otemp[3] = pack.payload[12]
        batt2.otemp[4] = pack.payload[13]
    return batt2

def ReadDataHandler(port):
    resp = _TTransferPacket()
    buf = [0]*20
    idx = 0
    state = 0
    complete = False

    
    try:

        ch = port.readline()
        print(ch)
                   
    except serial.SerialException:
        port.close()

    finally:
        port.reset_input_buffer()
        
    resp = GetTransferPacket(ch)
    # while not complete:
    #     # Check for the reserved 4-bit 0xD signal (USB tag)
    #     if state == 0 and ((ch >> 0) & 0xF) == 0xD:
    #         buf[idx] = int(ch[idx])
    #         state = 1
    #         idx += 1
    #     elif state == 1:
    #         buf[idx] = int(ch[idx])  # Paylen Data
    #         state = 2
    #         idx += 1
    #     elif state == 2:
    #         buf[idx] = int(ch[idx])  # Collect Remainder of Packet
    #         idx += 1
    #         if idx > buf[1] + state:
    #             state = 3
    #     elif state == 3:
    #         buf[idx] = int(ch[idx])  # Read Final Byte
    #         # Convert buffer into standard Transfer Packet format
    #         resp = GetTransferPacket(buf)
    #         complete = True

    # buf.clear()  # Clear the buffer
    return resp


def MakeRequest(port,request):
    response =_TTransferPacket()
    t = _TTransferPacket_Serial()
            
    t.reserved_and_type = ((_TransferType.REQUEST_DATA  << 4) | (0xD & 0xF))
    # print('reserved and typed',t.reserved_and_type)
    t.paylen = ctypes.sizeof(TRequestData)
    t.serial = 0
    t.payload = bytearray(ctypes.sizeof(TRequestData))
    t.payload[0] = request.request_type
    t.payload[1] = request.cycle
    print(t.paylen)
    buf = bytearray(20)
    buf[0] = t.reserved_and_type
    buf[1] = t.paylen
    buf[2] = ((t.serial >> 0) & 0xF)
    buf[3] = ((t.serial>> 4) & 0xF)
    buf[4] = t.payload[0]
    buf[5] = t.payload[1]
    print(buf)
    # print('CYCLE before send',request.cycle,t.payload[1])
    # buf = bytearray(buf)

    if( port.is_open ):
        try:
            # Write the byte buffer to the port
            # timmer = start()
            
            port.write(buf[:t.paylen + 4])  # Only send the relevant part of the buffer
            print('Sent:',buf[:t.paylen + 4])
            
            # print(f"Sent: {buf[:t.paylen + 4]}")
            
        except Exception as e:
            print(f"Failed to write: {e}")
            port.close()

    try:
        
        response = ReadDataHandler(port)
        #timmer.stop()
    
    except:
        port.close()

    return response

def RequestConnection(port):
    req = TRequestData()
    resp =TRequestData()
    
    req.request_type = _TransferType.REQUEST_DATA
    req.cycle = 0
    
    response = _TTransferPacket()
    response = MakeRequest(port, req)
    resp = GetRequestData(response)

    return resp

def RequestSystemData(port, cycle):
    req = TRequestData()
    # resp = TClientSysData()

    req.request_type = _TransferType.SYSTEM_DATA
    req.cycle = cycle
    response = _TTransferPacket()
    response = MakeRequest(port, req)
    resp = GetClientSysData(response)

    return resp

def RequestHitData(port, cycle):

    req = TRequestData()
    resp = TClientHitData()
    req.request_type = _TransferType.HIT_DATA
    req.cycle = cycle
    response = _TTransferPacket()
    response = MakeRequest(port, req)
    resp = GetHitData(response)

    return resp

def RequestGPSData(port, cycle):

    req = TRequestData()
    resp = TClientGPSData()
    req.request_type = _TransferType.GPS_DATA
    req.cycle = int(cycle)
    # print('req.cycle', req.cycle)
    response = _TTransferPacket()
    response = MakeRequest(port, req)
    resp = GetGPSData(response)
    return resp

def RequestBattData1(port, cycle):
    
    req = TRequestData()
    resp = TClientBattData1()
    req.request_type = _TransferType.BATT_DATA1
    req.cycle = cycle

    response = _TTransferPacket()
    
    response = MakeRequest(port, req)
    resp = GetBatt1Data(response)
    return resp

def RequestBattData2(port, cycle):
    req = TRequestData()
    resp = TClientBattData2()
    req.request_type = _TransferType.BATT_DATA2
    req.cycle = cycle
    response = _TTransferPacket()
    response = MakeRequest(port, req)
    resp = GetBatt2Data(response)
    return resp

def OpenPort(port):
    succ = False
    port.close()
    port.timeout = 0.5
    port.write_timeout = 0.5

    port.open()
    try:
        
        # RequestGPSData(port,1)

        # RequestHitData(port,1)
        
        # RequestBattData1(port, 1)
        # resp = TRequestData()
        
        resp = RequestConnection(port)
        
        if(resp.request_type == _TransferType.REQUEST_DATA):
            if(resp.cycle == 1):
                succ = True
        print('Cycle',resp.cycle)
        #succ = True

    except Exception as e:
        succ = False
        print('fail open: ',e)
            
    return succ

def FindPorts():
    controllers = []
    ports = GetPortNames()
    for port in ports:
        print(port)
        try:
            com = serial.Serial(port, 115200)
            
            com.timeout = 500 
            com.write_timeout = 500 
                    
            resp = TRequestData()
            resp = RequestConnection(com)

            if(resp.request_type == _TransferType.REQUEST_DATA):
                if(resp.cycle == 1):
                    controllers.append(port)
                      

            com.close()
        except:
            pass
            print('fail')
    return controllers

PORT = 'COM7'
BUAD = 115200
TIMEOUT = 0.5
WRITEOUT = TIMEOUT
port = serial.Serial('COM7',115200,
                     timeout=TIMEOUT,
                     write_timeout=WRITEOUT)


SIGNALS = {
    'system_data':False,
    'hit_data':False,
    'gps_data':False,
    'batt1_data':False,
    'batt2_data':False
}



def get_data(port,requests):
    for requester in requests:
        requester(port,1)
   
RequestConnection(port)
task_manager = Scheduler()
task_id, stopper = task_manager.looper(get_data,args=[port,(RequestBattData2,)])

time.sleep(5)
stopper()


if OpenPort(port):
    Batt = RequestGPSData(port,1)
    Batt.PrintAll()

