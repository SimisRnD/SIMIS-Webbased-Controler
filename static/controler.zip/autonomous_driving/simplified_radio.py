import serial
import serial.tools.list_ports
from backgroundtasks import Scheduler
import threading
TErrorCodeDict = {
    0x0001: "ERR_MOT1",
    0x0002: "ERR_MOT2",
    0x0004: "ERR_MOT3",
    0x0008: "ERR_MOT4",
    0x0010: "ERR_RADIO_HW",
    0x0020: "ERR_RADIO_PROTO",
    0x0040: "ERR_FAN_TOP",
    0x0080: "ERR_FAN_BOT",
    0x0100: "ERR_NO_BATTERY",
    0x0200: "ERR_NO_HITDET",
    0x0400: "ERR_NO_RISER",
    0x0800: "ERR_NO_GPS1",
    0x1000: "ERR_NO_GPS2",
    0x2000: "ERR_MOT_NOTRDY",
    0x4000: "ERR_FAN_PDB",
}

def get_errors(errorbits):
    """Determine which errors are present in the given bitmask."""
    return [TErrorCodeDict[bit] for bit in TErrorCodeDict if errorbits & bit]


class Data:
    def __init__(self):
        pass
    def GetAll(self):
        data = {}
        for att, val in vars(self).items():
            data[att] = val
        return data
    def PrintAll(self):
        data = self.GetAll()
        for att in data:
            print(f'{att} = {data[att]}')

class TClientSysData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'System Data'
        self.serial = 0
        self.clientId = 0
        self.state = 0
        self.errorbits = 0
        self.pathName_raw = 0
        self.pathName = 0

    def decode(self,pack):
        #Data Pack each [] is a byte of the byte array
        #[usb-head][paylen][serial][serial]<[client-id][state][err][err][pathname]...>
        paylen = pack[1]
        self.serial = (pack[3] << 8) | (pack[2] & 0xFF)
        self.clientId = pack[4]
        self.state = pack[5]
        self.errorbits = get_errors((pack[4+3] << 8) | (pack[4+2]&0xFF))
        self.pathName_raw = []
        self.pathName = ''
        for i in range(4,paylen):
            self.pathName_raw.append(pack[4+i])
            self.pathName+=str(pack[4+i])


class TClientHitData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Hit Data'
        self.hitThreshold = 0
        self.hitTimeLimit = 0
        self.HdSensitivity = 0
        self.hitPauseTime = 0
        self.hit_zone_data = 0
        self.zonesEnable = 0

    def decode(self,pack):
        #Data Pack each [] is a byte of the byte array
        #[usb-head][paylen][serial][serial]<[thresh][timelimit][sensitivity][pausetime][zoneEnabled]>
        paylen = pack[1]
        self.serial = (pack[3] << 8) | (pack[2] & 0xFF)
        self.hitThreshold = pack[4]
        self.hitTimeLimit = pack[5]
        self.HdSensitivity = pack[6]
        self.hitPauseTime = pack[7]
        self.hit_zone_data = pack[8]
        self.zonesEnable = bool(pack[9])

class TClientGPSData(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'GPS Data'
        self.utmX = 0
        self.utmY = 0
        self.utmZone = 0
        self.numSat = 0
        self.gpsFix = 0
        self.COG = 0
        self.speed = 0
    def decode(self,pack):
        #Data Pack each [] is a byte of the byte array
        #[usb-head][paylen][serial][serial]
        #<[thresh][timelimit][sensitivity][pausetime][zoneEnabled]>
        paylen = pack[1]
        self.serial = (pack[3] << 8) | (pack[2] & 0xFF)

        raw_utmX = ((pack[4+3] << 24) | (pack[4+2] << 16) | (pack[4+1] << 8) | (pack[4+0] & 0xFF))
        raw_utmY = ((pack[4+7] << 24) | (pack[4+6] << 16) | (pack[4+5] << 8) | (pack[4+4] & 0xFF))
        self.utmX = raw_utmX / 10.
        self.utmY = raw_utmY / 10.
        self.utmZone =  [0,0,0,0]
        self.utmZone[0] = pack[4+8]
        self.utmZone[1] = pack[4+9]
        self.utmZone[2] = pack[4+10]
        self.utmZone[3] = pack[4+11]
        self.numSat = pack[4+12]
        self.gpsFix =  pack[4+13]
        self.COG = pack[4+14]
        self.speed = pack[4+15]


class TClientBattData1(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Battery 1 Data'
        self.bvolt = 0
        self.bcap = 0
        self.bcur = 0
    def decode(self,pack):
        #Data Pack each [] is a byte of the byte array
        #[usb-head][paylen][serial][serial]
        #<[thresh][timelimit][sensitivity][pausetime][zoneEnabled]>
        paylen = pack[1]
        self.serial = (pack[3] << 8) | (pack[2] & 0xFF)

        self.bvolt = [0,0]
        self.bvolt[0] = ((pack[4+1] << 8) | (pack[4+0] & 0xFF))
        self.bvolt[1] = ((pack[4+3] << 8) | (pack[4+2] & 0xFF))
        self.bcap = [0,0,0]
        self.bcap[0] = pack[4+4]
        self.bcap[1] = pack[4+5]
        self.bcap[2] = pack[4+6]
        self.bcur = [0,0,0]
        self.bcur[0] = ((pack[4+8] << 8) | (pack[4+7] & 0xFF))
        self.bcur[1] = ((pack[4+10] << 8) | (pack[4+9] & 0xFF))
        self.bcur[2] = ((pack[4+12] << 8) | (pack[4+11] & 0xFF))
    


class TClientBattData2(Data):
    def __init__(self):
        super().__init__()
        self.data_name = 'Battery 2 Data'
        self.btemp1 = 0
        self.btemp2 = 0
        self.btemp3 = 0
        self.btemp4 = 0 #Other Voltage
    def decode(self,pack):
        #Data Pack each [] is a byte of the byte array
        #[usb-head][paylen][serial][serial]
        #<[thresh][timelimit][sensitivity][pausetime][zoneEnabled]>
        paylen = pack[1]
        self.serial = (pack[3] << 8) | (pack[2] & 0xFF)

        self.btemp1 = [0,0,0]
        self.btemp1[0] = pack[4+0]
        self.btemp1[1] = pack[4+1]
        self.btemp1[2] = pack[4+2]
        self.btemp2 = [0,0,0]
        self.btemp2[0] = pack[4+3]
        self.btemp2[1] = pack[4+4]
        self.btemp2[2] = pack[4+5]
        self.btemp3 = [0,0,0]
        self.btemp3[0] = pack[4+6]
        self.btemp3[1] = pack[4+7]
        self.btemp3[2] = pack[4+8]
        self.btemp4 = pack[4+9]
        # self.otemp = [0,0,0,0,0]
        # self.otemp[0] = pack[4+9]
        # self.otemp[1] = pack[4+10]
        # self.otemp[2] = pack[4+11]
        # self.otemp[3] = pack[4+12]
        # self.otemp[4] = pack[4+13]


# class TClientPathWithSpaceData(Data):
#     def __init__(self):
#         self.data_name = 'Path Data'
#         self.name_raw = 0
#         self.name = 0
#         self.pathdate = 0
#         self.pathtime = 0
#         self.lat0 = 0
#         self.lon0 = 0
#         self.x0 = 0
#         self.y0 = 0
#         self.npts = 0
#         self.curpt = 0
#         self.x = 0
#         self.y = 0
#         self.flag = 0                  


def getPortDetails():
    ports = serial.tools.list_ports.comports()
    port_details = [
        (port.device, port.description, port.hwid) for port in ports
    ]
    #print(port_details)
    return port_details

def usbPorts():
    ports = getPortDetails()
    usb_ports = []
    for port, description, hwid in ports:
        if 'usb' in hwid.lower():
            usb_ports.append(port)
    return usb_ports

def openPort(port=usbPorts()[0],baud=115200,timeout=0.5,writeout=0.5):
    port = serial.Serial(port=port,baudrate=baud,
                         timeout=timeout,write_timeout=writeout)
    return port

class RequestPackets:
    headers = {'usb':0xD,
               'request':0,
               'system':1,
               'hit':2,
               'gps':3,
               'bat1':4,
               'bat2':5,
               'up':10,
               'down':11,
               'half':12,}
    paylen = 2
    
    def get(self,data='request',cycle=1,serial=1201):
        packet_ = bytearray(6)
        packet_[0] = self.headers['usb']
        packet_[1] = self.paylen
        packet_[2] = ((serial >> 0) & 0xF)
        packet_[3] = ((serial>> 4) & 0xF)
        packet_[4] = self.headers[data]
        packet_[5] = cycle
        print('Packet',packet_)
        return packet_


class CommandPackets:
    headers = {'usb':0xD,
                'up':10,
               'down':11,
               'half':12,
               'joy':13,
               'On/Off':14,
               }
    paylen = 2
    joy_paylen = 5
    
    def get(self,data='request',cycle=1,serial=1201,joyx=0,joyy=0,joyz=0):
        paylen = self.paylen if data!='joy' else self.joy_paylen
        packet_ = bytearray(4+paylen)
        packet_[0] = self.headers['usb']
        packet_[1] = paylen
        packet_[2] = serial & 0xFF
        packet_[3] = (serial >> 8) & 0xFF
        packet_[4] = self.headers[data]
        packet_[5] = cycle
        if data == 'joy':
            packet_[6] = (joyx + 100)
            packet_[7] = (joyy + 100) 
            packet_[8] = (joyz + 100)
            print(joyx,joyy,joyz)

        print('Packet',packet_)
        return packet_

class PortManager:
    Packet = RequestPackets()
    Que = []
    def __init__(self,port=usbPorts()[0],baud=115200,
                 timeout=0.5,writeout=0.5):
        self.port = openPort(port,baud,timeout,writeout)
        self.run = True
        self.data ={
            # 'request':TClientSysData(),
               'system':TClientSysData(),
               'hit':TClientHitData(),
               'gps':TClientGPSData(),
               'bat1':TClientBattData1(),
            #    'bat2':TClientBattData2(),
            #    'path':TClientPathWithSpaceData()
        }
        # self.thread = threading.Thread(target=self._send)
        # self.thread.start()
        
    
    def stop(self):
        self.run = False

    def _send(self):
        while self.run:
            if self.Que:
                data = self.Que.pop(0)
                self.port.write(data)
                # print(self.port.readline())
            else:
                pass

        
    
    def send(self,data):
        print(f'Sending:{data}')
        # self.Que.append(data)
        self.port.write(data)
        return(self.port.readline())
    
    def read(self,dataType=None):
        # if dataType:
        #     return self.data[dataType].decode(self.port.read()).GetAll
        return self.port.readline()
    
    def request(self,data):
        packet = self.Packet.get(data)
        self.send(packet)
        return self.read()
    
class HTTServer:
    def __init__(self):
        self.PM = PortManager()
        self.TM = Scheduler()
        
        self.data ={
            'request':TClientSysData(),
               'system':TClientSysData(),
               'hit':TClientHitData(),
               'gps':TClientGPSData(),
               'bat1':TClientBattData1(),
            #    'bat2':TClientBattData2(),
            #    'path':TClientPathWithSpaceData()
        }
        self.task_id = None
        self.task_stop = None
    def start(self):
        self.task_id, self.task_stop = self.TM.looper(self.task,time_int=0.1)
        
    def task(self):
        for type_ in self.data:
            rawdata = self.PM.request(type_)
            self.data[type_].decode(rawdata)

    def stop(self):
        print('Stopping Server')
        self.task_stop()

    def get(self,data_type):
        return self.data[data_type]



# PM = PortManager()
# systemdata = TClientSysData()
# systemdataraw = PM.request('system')
# systemdata.decode(systemdataraw)
# systemdata.PrintAll()
# print('\n')
# hitdata = TClientHitData()
# hitdataraw = PM.request('hit')
# hitdata.decode(hitdataraw)
# hitdata.PrintAll()
# print('\n')
# gpsdata = TClientGPSData()
# gpsdataraw = PM.request('gps')
# gpsdata.decode(gpsdataraw)
# gpsdata.PrintAll()
# print('\n')
# data = TClientBattData1()
# dataraw = PM.request('bat1')
# data.decode(dataraw)
# data.PrintAll()
# data = TClientBattData2()
# dataraw = PM.request('bat2')
# print(dataraw)
# data.decode(dataraw)
# data.PrintAll()
# dataraw = PM.request('path')
# print(dataraw)



import time

# server = HTTServer()
# server.start()
# RUN = True


# time.sleep(2)
# server.get('system').PrintAll()
# server.stop()




RP = RequestPackets()
CP = CommandPackets()
PM = PortManager()

# packet = CP.get('On/Off')
# PM.send(packet)
# print(PM.read())
def sendJoyStickCMD(jx,jy,jz):
    global CP, PM
    packet = CP.get('joy',
    joyx=jx,
    joyy=jy,
    joyz=jz)
    
    pack = PM.send(packet)
    paylen = pack[1]
    serial = (pack[3] << 8) | (pack[2] & 0xFF)
    jx = pack[4]-100
    jy = pack[5]-100
    jz = pack[6]-100
    print(paylen)
    print(serial)
    print(jx,jy,jz)

# for i in range(10):
#     time.sleep(0.25)
# sendJoyStickCMD(100,0,0)
def sendRaiseTorsoCMD():
    global CP, PM
    packet = RP.get('up')
    PM.send(packet)

def sendLowerTorsoCMD():
    global CP, PM
    packet = RP.get('down')
    PM.send(packet)
    

def sendHalfTorsoCMD():
    global CP, PM
    packet = RP.get('half')
    PM.send(packet)

def power():
    global CP, PM
    packet = CP.get('On/Off')
    PM.send(packet)

def get_all_data():
    global CP, PM
    # p1 = RP.get('request')
    # PM.send(p1)
    # PM.read()
    data_struct = TClientGPSData()
    packet = RP.get('system')
    k =PM.send(packet)
    
    print(k)
    data_struct.decode(k)
    data_struct.PrintAll()

# get_all_data()
# sendLowerTorsoCMD()
# # time.sleep(2)
# # sendRaiseTorsoCMD()
# for i in range(10):
#     sendJoyStickCMD(-100,0,0)
#     time.sleep(0.5)

# for i in range(50):
#     time.sleep(0.25)
#     sendJoyStickCMD(90,90,0)