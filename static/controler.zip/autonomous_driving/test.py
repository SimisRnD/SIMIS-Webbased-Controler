import time
import threading

def start(interval=0.1):
    temp = Timer(interval)
    threading.Thread(target=temp.start, daemon=True).start()  # Daemon thread so it doesn't block the main program
    return temp

class Timer:
    def __init__(self, interval=0.1):
        self.interval = interval
        self.running = True
        self.last_printed = None  # To store the last printed time value

    def start(self):
        dt = 0
        time_ = time.time()
        print("Timer started.", end="\r")  # Initial message, use \r to stay on the same line
        while self.running:
            time.sleep(self.interval)
            dt = time.time() - time_
            
            # If the printed time value has changed, print it on the same line
            print(f"{dt:.2f}", end="\r", flush=True)  # Overwrites the previous print on the same line

    def stop(self):
        self.running = False
        print()  # Ensure a newline after stopping the timer

# Example usage
if __name__ == "__main__":
    timer = start(0.5)  # Start timer with 0.1 second interval

    # Simulate main program doing other things
    for i in range(5):
        time.sleep(1)
        print(f"Main program is doing something: iteration {i+1}")
    
    timer.stop()  # Stop the timer after 5 seconds
