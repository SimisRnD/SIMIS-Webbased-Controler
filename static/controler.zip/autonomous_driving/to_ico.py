from PIL import Image
import sys

def convert_png_to_ico(png_file, ico_file):
    try:
        # Open the PNG file
        image = Image.open(png_file)
        
        # Save the image as .ico
        image.save(ico_file, format='ICO')
        print(f"Successfully converted {png_file} to {ico_file}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":

    
    # Get input PNG file and output ICO file from command line arguments
    input_png = 'static/simislogo.png'
    output_ico ='static/simislogo.ico'
    
    # Convert PNG to ICO
    convert_png_to_ico(input_png, output_ico)
